<div class="panel panel-primary">
  <div class="panel-heading">
    <h2>Kententuan PPDB <strong class="text-success" style="color:#eee;">SMP NEGERI 4 TAPUNG</strong></h2>
    <span style="font-size:18px;">Sekolah <b>SMP NEGERI 4 TAPUNG</b> Tahun Ajaran <b><?php echo date('Y'); ?>-<?php echo date('Y')+1; ?></b></span>
    <!-- <hr> -->
  </div>
  <div class="panel-body">

    <ol style="color:#333;">

      <li>Setiap calon siswa wajib membaca prosedur pendaftaran terlebih dahulu. </li>

      <li>Setiap calon siswa wajib mengisi form pendaftaran dengan lengkap.</li>

      <li>Siapkan pas foto berwarna dalam format JPG maksimal berukuran 2MB yang akan di-upload melalui form pendaftaran PPDB Online.</li>

      <li>Siapkan nilai rapor semester I dan II untuk pengisian kolom nilai yang akan dimasukkan dalam form isian nilai rapor pada PPDB Online.</li>

      <li>Calon siswa yang sudah mendaftarkan secara online akan mendapatkan Nomor Pendaftaran yang harus dicetak dan dilampirkan dalam persyaratan yang diminta oleh Sekolah </li>

    </ol>

  </div>
</div>
